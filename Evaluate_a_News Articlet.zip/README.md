Udacity FEND - Evaluate a News Article with Natural Language Processing


Description
This is the last project in this Nano degree course and uses the MeaningCloud API to analize a user provided URL to check for objectivity-subjectivity. 
A local server running Node and the build tool web pack is utilized.

As I could not submit the node_modules folder the first thing that needs to be done is to run "npm install".

The following commands can be run in the terminal:

npm run test
npm run build-dev
npm run build-prod
npm run start