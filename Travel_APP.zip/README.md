Udacity FEND - Travel app


Description
This is the capstone project in this Nano degree course and uses the three different APIs to give information to user provided travel destination and travel dates.
The app the returns the country the destination is located in, the weather conditions at the time of departure, the trip duration and a picture associated with the destination.
If the departure date is too far in the future the weather conditions will be based on historical data.

A local server running Node and the build tool web pack is utilized.

As I could not submit the node_modules folder the first thing that needs to be done is to run "npm install".

The following commands can be run in the terminal:

npm run test
npm run build-dev
npm run build-prod
npm run start

Note: To extend my project further I chose to implement the trip duration also. For this the end date is added.